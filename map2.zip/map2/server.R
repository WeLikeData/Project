# Install leaflet package
if(!require(leaflet)) install_github("rstudio/leaflet")

library(shiny)
library(leaflet)
library(dplyr)

load("sample2.rda")
data <- quick3[sample(1:nrow(quick3), 10000, replace=FALSE),]

server <- function(input,output) {
  points <- data[c("LAT","LON", "Service.Name", "DOW")]
  points$LAT <- jitter(points$LAT, factor = 10)
  points$LON <- jitter(points$LON, factor = 10)
  
  output$mymap <- renderLeaflet({
    leaflet() %>%
      addProviderTiles("Stamen.TonerLite",
                       options = providerTileOptions(noWrap = TRUE)
      ) %>%
      setView(-118.4, 34, 9) %>%
      addCircleMarkers(data = filter(points, points$DOW == input$days), 
                       radius = 2,
                       fillOpacity = 1/5,
                       color = "transparent",
                       fillColor = "red")
  })
}