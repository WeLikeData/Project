load("sample1.rda")
library(dplyr)
quick3 <- quick2 %>%
  filter(!is.na(INTPTLAT))
colnames(quick3)[c(13,14)] = c("LAT","LON")
save(quick3, file = "sample2.rda")
load("sample2.rda")
