# Install leaflet package
if(!require(leaflet)) install_github("rstudio/leaflet")

library(shiny)
library(leaflet)

ui <- fluidPage(
  titlePanel("311 Calls by Day of Week and Approximate Origin"),
  fluidRow(
  column(3,
         radioButtons("days", 
                     label = h3("Select day(s)."), 
                     choices = list("Monday",
                                    "Tuesday",
                                    "Wednesday",
                                    "Thursday",
                                    "Friday",
                                    "Saturday",
                                    "Sunday")
                     )
  ),
  
  column(9, leafletOutput("mymap"))
))